"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, X, ChevronDown, Phone } from "lucide-react";
import { site, industries } from "@/lib/site";

const navLinks = [
  { label: "About", href: "/about" },
  {
    label: "Industries",
    href: "/industries",
    children: industries.map((i) => ({
      label: i.name,
      href: `/industries/${i.slug}`,
    })),
  },
  { label: "Services", href: "/services" },
  { label: "Jobs", href: "/jobs" },
  { label: "Blog", href: "/blog" },
];

export default function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState(null);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 w-full transition-all duration-300 ${scrolled
        ? "border-b border-slate-200 bg-white/90 shadow-sm backdrop-blur-md"
        : "border-b border-transparent bg-white"
        }`}
    >
      {/* Utility bar */}
      <div
        className={`hidden overflow-hidden bg-ink text-slate-300 transition-all duration-300 md:block ${scrolled ? "max-h-0 opacity-0" : "max-h-10 opacity-100"
          }`}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-end gap-6 px-6 py-2 text-xs tracking-wide">
          <a href={`tel:${site.phone}`} className="flex items-center gap-1.5 hover:text-white">
            <Phone size={13} />
            {site.phoneDisplay}
          </a>
          <a href={`mailto:${site.email}`} className="hover:text-white">
            {site.email}
          </a>
        </div>
      </div>

      {/* Main nav */}
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-3 md:py-3">
        <Link href="/" className="">
          <span className="pt-1">
            <img src="/ch-logo-new.webp" alt="Career Hire" className="block h-auto w-40" />
          </span>
        </Link>

        <nav className="hidden items-center gap-8 lg:flex">
          {navLinks.map((link) =>
            link.children ? (
              <div
                key={link.label}
                className="relative"
                onMouseEnter={() => setOpenDropdown(link.label)}
                onMouseLeave={() => setOpenDropdown(null)}
              >
                <button className="flex items-center gap-1 text-base font-semibold text-ink/80 transition hover:text-brand">
                  {link.label}
                  <ChevronDown
                    size={14}
                    className={`transition-transform duration-200 ${openDropdown === link.label ? "rotate-180" : ""
                      }`}
                  />
                </button>
                <AnimatePresence>
                  {openDropdown === link.label && (
                    <motion.div
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 8 }}
                      transition={{ duration: 0.18 }}
                      className="absolute left-0 top-full w-60 overflow-hidden rounded-xl border border-slate-100 bg-white py-2 shadow-2xl shadow-slate-900/10"
                    >
                      {link.children.map((child) => (
                        <Link
                          key={child.href}
                          href={child.href}
                          className="flex items-center justify-between px-4 py-2.5 text-sm font-medium text-slate-700 transition hover:bg-red-50 hover:text-brand"
                        >
                          {child.label}
                        </Link>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <Link
                key={link.href}
                href={link.href}
                className="text-base font-semibold text-ink/80 transition hover:text-brand"
              >
                {link.label}
              </Link>
            )
          )}
        </nav>

        <div className="hidden lg:block">
          <Link
            href="/contact"
            className="group relative inline-flex items-center overflow-hidden rounded-full bg-brand px-6 py-2.5 text-sm font-semibold text-white shadow-lg shadow-red-900/20 transition hover:shadow-red-900/30"
          >
            <span className="relative z-10">Request a Service</span>
            <span className="absolute inset-0 -translate-x-full bg-brand-dark transition-transform duration-300 group-hover:translate-x-0" />
          </Link>
        </div>

        <button
          className="text-ink lg:hidden"
          onClick={() => setMobileOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden border-t border-slate-100 bg-white lg:hidden"
          >
            <nav className="flex flex-col px-6 py-4">
              {navLinks.map((link) => (
                <div key={link.label} className="py-2">
                  <Link
                    href={link.href}
                    className="block text-sm font-semibold text-ink"
                    onClick={() => setMobileOpen(false)}
                  >
                    {link.label}
                  </Link>
                  {link.children && (
                    <div className="mt-2 flex flex-col gap-2 pl-3">
                      {link.children.map((child) => (
                        <Link
                          key={child.href}
                          href={child.href}
                          className="text-sm text-slate-600"
                          onClick={() => setMobileOpen(false)}
                        >
                          {child.label}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              <Link
                href="/contact"
                className="mt-3 rounded-full bg-brand px-5 py-2.5 text-center text-sm font-semibold text-white"
                onClick={() => setMobileOpen(false)}
              >
                Request a Service
              </Link>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
